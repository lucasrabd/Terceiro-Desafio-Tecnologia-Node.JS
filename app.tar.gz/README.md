# Terceiro-Desafio-Tecnologia-Node.JS

# WellDone
- Bruno Ramos da Costa(RM551942)
- Guilherme Faria de Aguiar(RM551374)
- Henrique Roncon Pereira (RM99161)
- Lucas Carabolad Bob (RM550519)
- Thiago Ulrych (RM97951)

## Introdução
A equipe de DevOps da DimDim foi encarregada de realizar testes de migração do ambiente de desenvolvimento para Containers Docker, utilizando as tecnologias Java, Python e NodeJS. Este repositório documenta o processo de implantação dessas tecnologias em containers e a coleta de evidências para a equipe de Arquitetura da DimDim.

## Em desenvolvimento....
